package transformadores;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class XML2JSON extends AbstractMessageTransformer {

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding)
			throws TransformerException {
		
		//La cadena que li ve
		String xml=(String)message.getPayload();
		
		//EL nostre JSON final
		JSONArray jsonList=new JSONArray();
		
		try{
		    Document document = DocumentHelper.parseText(xml);
		    //Llista dels punts
		    List<Node> locations = document.selectNodes("//Placemark");
		    //Lista de les coordenades
		    List<Node> coords = document.selectNodes("//Point");
		    //Lista on afegirem les coordenades al JSON
		    List<Double> cds = new ArrayList<Double>();
		    int counter = -1;

		    for(Node n:locations){
		    	
		    	//El JSON on ficarem les "properties"
		    	JSONObject obj=new JSONObject();
		    	//El JSON de les "properties"
		    	JSONObject prop=new JSONObject();
		    	counter++;		    	

		    	//Seleccionem el nom dins del KML i el fiquem dins del JSONObject que hem creat
		    	Node nombreNode=n.selectSingleNode("name");
		    	prop.put("name", nombreNode.getStringValue()); 
		    	
		    	//Igual pero amb la descripci�
		    	Node descNode=n.selectSingleNode("description");
		    	prop.put("desc", descNode.getStringValue());
		    		
		    	//Igual pero amb les coordenades. M'ha tocat fer un xanxullo per a poder agarrar el "Point" que toca, pero funciona dpm
		    	Node coordinateNode = coords.get(counter).selectSingleNode("coordinates");
		    	String coordenadas = coordinateNode.getStringValue();
		    	double latitud = Double.parseDouble(coordenadas.split(",")[0]);
		    	double longitud = Double.parseDouble(coordenadas.split(",")[1]);
		    	//Afegim les coordenades a la llista
		    	cds.add(0, latitud);
		    	cds.add(1, longitud);
		    		
		    	//Afegim el JSON "properties" dins del JSON que ficarem en el document
		    	obj.put("properties", prop);
		    	//Afegim les coordinades dins del JSON que ficarem en el document
		    	obj.put("coordinates", cds);
		    	
		    	//Afegim al document el JSON complet de la localitzaci� que hem transformat
		    	jsonList.put(obj);
		    	
		    }
		    
		    
		}catch(Exception e){ 
			e.printStackTrace(); 
		}

		return jsonList.toString();

	}

}
