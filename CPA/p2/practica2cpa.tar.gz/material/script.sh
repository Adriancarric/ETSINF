#!/bin/sh
#PBS -l nodes=1,walltime=00:05:00
#PBS -j oe
#PBS -q cpa
#PBS -d .

OMP_NUM_THREADS=3 ./simil-ejercicio7b donantes.txt pacientes.txt salida.txt
