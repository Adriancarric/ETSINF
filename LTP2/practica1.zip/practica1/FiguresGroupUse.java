
/**
 * class FiguresGroupUse.
 * 
 * @author LTP 
 * @version 2017-18
 */
public class FiguresGroupUse {
    public static void main(String[] args) {
        FiguresGroup g = new FiguresGroup();
        g.add(new Circle(10, 5, 3.5));
        g.add(new Triangle(10, 5, 6.5, 32));
        System.out.println(g);
    }
}