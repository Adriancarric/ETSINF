module Triangle(areaTriangle)
	where

	areaTriangle :: Float -> Float -> Float
	areaTriangle base altura :: (base * altura) / 2
