module Circle(areaCircle)
	where
	
	areaCircle :: Float -> Float
	areaCircle radio = 2 * 3.14 * radio
