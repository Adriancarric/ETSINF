import java.io.*;
import java.util.*;
/**
 * Write a description of class UsoDeArrayList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class UsoDeArrayList 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        File archivo = new File("archivo.txt");
    }
}
